package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Shelter_Request")
public class ShelterRequest {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private int shelter_reqid;
	
	@Column(name = "VICTIM_ID")
    private int victim_id;
	
	@Column(name = "SHELTER_ID")
    private int shelter_id;
	
	@Column(name = "DATE")
    private String date;
	
	@Column(name = "VC1_NAME")
    private String name1;
	
	@Column(name = "VC1_AGE")
    private int age1;
	
	@Column(name = "GENDER1")
    private String gender1;
	
	@Column(name = "VC2_NAME")
    private String name2;
	
	@Column(name = "VC2_AGE")
    private int age2;
	
	@Column(name = "GENDER2")
    private String gender2;
	
	@Column(name = "VC3_NAME")
    private String name3;
	
	@Column(name = "VC3_AGE")
    private int age3;
	
	@Column(name = "GENDER3")
    private String gender3;
	
	@Column(name = "VC4_NAME")
    private String name4;
	
	@Column(name = "VC4_AGE")
    private int age4;
	
	@Column(name = "GENDER4")
    private String gender4;
	
	@Column(name = "VC5_NAME")
    private String name5;
	
	@Column(name = "VC5_AGE")
    private int age5;
	
	@Column(name = "GENDER5")
    private String gender5;
	
	@Column(name = "VC6_NAME")
    private String name6;
	
	@Column(name = "VC6_AGE")
    private int age6;
	
	@Column(name = "GENDER6")
    private String gender6;
	
	public ShelterRequest() {
	}





}
