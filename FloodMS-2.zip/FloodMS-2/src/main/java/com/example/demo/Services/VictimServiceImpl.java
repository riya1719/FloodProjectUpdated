package com.example.demo.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.model.Victim;
import com.example.demo.repository.VictimRepository;

@Service
public class VictimServiceImpl implements VictimService {
	
	@Autowired
	private VictimRepository victimRepository;
	
	
	
	@Override
	public Victim addVictim(Victim victims) {
		
		victimRepository.save(victims);
		return victims;
	}

	@Override
	public List<Victim> getVictim() 
	//find all o return all vicitms
	{		
		return victimRepository.findAll();
		
	}
	 
	    @Override 
		public Optional<Victim> getVictimById(long victim_id)
		{
	    	return victimRepository.findById(victim_id); 
	    	}
	    
		@Override
		public List<Victim> find()
		{
			List<Victim> listVictim = new ArrayList<>();
			listVictim = victimRepository.findAll();
			return listVictim;
		}
		
		@Override
		public List<Victim> findByVictim(String vname)
		{
			List<Victim> listVictim = new ArrayList<>();
			listVictim = victimRepository.findByVictim(vname);
			return listVictim;
		}

	    
	    
}
