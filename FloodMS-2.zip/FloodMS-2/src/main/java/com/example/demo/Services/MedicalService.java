package com.example.demo.Services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Medical;

@Service
public interface MedicalService {
	
	Medical addMedical(Medical medicals);
	
	public List<Medical> getMedical(); 

}

