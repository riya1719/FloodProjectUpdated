package com.example.demo.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.model.Victim;

@Service
public interface VictimService {
	
	Victim addVictim(Victim victims);
	
	public List<Victim> getVictim(); 
	    
	Optional<Victim> getVictimById(long victim_id);
	
	// List<Victim> findAllUsername(String username);
	
	List<Victim> find();
	
	List<Victim> findByVictim(String vname);



}
